<?php
    require_once($_SERVER['DOCUMENT_ROOT'] . '/php/phpmailer/phpmailer.php');

		// *** SMTP *** //

		 // require_once($_SERVER['DOCUMENT_ROOT'] . '/php/phpmailer/smtp.php');
		 // const HOST = '';
		 // const LOGIN = '';
		 // const PASS = '';
		 // const PORT = '';

		// *** /SMTP *** //
   
	const SENDER = 'brezdina@ukr.net';
    const CATCHER = 'jessok3@gmail.com';
    const SUBJECT = 'Заявка с сайта AfganKazan';
    const CHARSET = 'UTF-8';
    